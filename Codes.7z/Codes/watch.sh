#!/bin/bash

xdg-open example.pdf

