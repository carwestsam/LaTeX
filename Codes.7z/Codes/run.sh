#!/bin/bash

pdflatex example.tex
xdg-open example.pdf

